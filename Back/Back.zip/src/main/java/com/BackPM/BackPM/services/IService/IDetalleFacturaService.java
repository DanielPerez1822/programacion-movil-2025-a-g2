package com.BackPM.BackPM.services.IService;


import com.BackPM.BackPM.models.Detalle_Factura;

public interface IDetalleFacturaService extends IBaseService<Detalle_Factura> {
    
    // Empleado findByNombreEmpleado(String nombreEmpleado);

}
