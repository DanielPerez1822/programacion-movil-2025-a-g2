export class Administrador {
  id: number;
  nombre: string;
  telefono: number;

  constructor(id: number, nombre: string, telefono: number) {
    this.id = id;
    this.nombre = nombre;
    this.telefono = telefono;
  }
}
