// archivo de conexión a la API
// Se utiliza para definir la URL de la API y otros parámetros de configuración

// Puerto de Luis Meneses
// export const API_URL = import.meta.env.VITE_API_URL || 'https://4vz8r50b-9000.use.devtunnels.ms';

// Daniel Perez
export const API_URL = import.meta.env.VITE_API_URL || 'https://3r7vcx2t-9000.use2.devtunnels.ms';

//Luis Bonilla
//export const API_URL = import.meta.env.VITE_API_URL || 'https://39xkz55p-9000.use2.devtunnels.ms';