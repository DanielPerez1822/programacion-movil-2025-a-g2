export class Categoria {
  id: number;
  nombreCategoria: string;

  constructor(id: number, nombreCategoria: string) {
    this.id = id;
    this.nombreCategoria = nombreCategoria;
  }
}
